// eslint-disable-next-line import/no-anonymous-default-export
export default {
  masterChef: {
    97: "0x1d32c2945C8FDCBc7156c553B7cEa4325a17f4f9",
    56: "0x73feaa1eE314F8c655E354234017bE2193C9E24E",
  },

  cgChef: {
    4: "0xbf25B8c9dF7f0C899F2C69c0210cE3046eF2f28d",
    1: "",
    56: "",
    97: "",
  },
  multiCall: {
    1: '0xeefba1e63905ef1d7acba5a8513c70307c1ce441',
    4: '0x42ad527de7d4e9d9d011ac45b31d8551f8fe9821',
    56: '0x1ee38d535d541c55c9dae27b12edf090c608e6fb',
    97: '0x67ADCB4dF3931b0C5Da724058ADC2174a9844412',
  },
};
