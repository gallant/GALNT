export interface IHome {
  
}