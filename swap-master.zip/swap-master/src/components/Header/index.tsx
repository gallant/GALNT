import { Text } from 'components/Text'

export default function Header() {

  return (
    <Text>Header</Text>

    )
}
